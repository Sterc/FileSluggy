FileSluggy
--------------------
Version: 1.1
Author: Friso Speulman <friso@sterc.nl>
		Wieger Sloot <wieger@sterc.nl>
--------------------

A MODx Revolution plugin to convert a filename to lowercases and removes strange characters.
Works on the "OnFileManagerUpload" event. 


Suggestions and Bugs can be emailed to :modx@sterc.nl
